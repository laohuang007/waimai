<?php


namespace app\common\enum;


class ExportEnum
{
    //获取导出信息
    const INFO = 1;
    //导出excel
    const EXPORT = 2;

}